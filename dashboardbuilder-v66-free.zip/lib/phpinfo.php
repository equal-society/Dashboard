<?php
 phpinfo();
